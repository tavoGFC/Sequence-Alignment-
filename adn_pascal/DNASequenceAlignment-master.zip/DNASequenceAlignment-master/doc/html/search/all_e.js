var searchData=
[
  ['scanint',['scanInt',['../ioperipherals_8c.html#a84dbd34a738ce2f61e3b233e6b13ded0',1,'scanInt(int *data):&#160;ioperipherals.c'],['../ioperipherals_8h.html#a84dbd34a738ce2f61e3b233e6b13ded0',1,'scanInt(int *data):&#160;ioperipherals.c']]],
  ['scanstring',['scanString',['../ioperipherals_8c.html#ab0c80ef6a68ce51b5fe952ee46bb6fe9',1,'scanString():&#160;ioperipherals.c'],['../ioperipherals_8h.html#ab0c80ef6a68ce51b5fe952ee46bb6fe9',1,'scanString():&#160;ioperipherals.c']]],
  ['score_5fmatrix',['SCORE_MATRIX',['../secuence_alignment_8h.html#af05d5e81328c419aca4f1613123efd15',1,'secuenceAlignment.h']]],
  ['secuencealignment_2ec',['secuenceAlignment.c',['../secuence_alignment_8c.html',1,'']]],
  ['secuencealignment_2eh',['secuenceAlignment.h',['../secuence_alignment_8h.html',1,'']]],
  ['secuencegenerator_2ec',['secuenceGenerator.c',['../secuence_generator_8c.html',1,'']]],
  ['similarity_5fmatrix',['SIMILARITY_MATRIX',['../secuence_alignment_8c.html#a644fda768f24a8e4598f8c8749044bb2',1,'secuenceAlignment.c']]]
];
