var searchData=
[
  ['flushinputbuffer',['flushInputBuffer',['../ioperipherals_8c.html#a377b5ba2bf90a8fcb6cfb7790bb4344b',1,'ioperipherals.c']]]
];
