var searchData=
[
  ['next',['next',['../structdynamic_char.html#a22454f85c7e0f91bd08e23b3cbf9e9fc',1,'dynamicChar']]],
  ['nodechar',['NodeChar',['../ioperipherals_8c.html#af7d91defb53e7090cef4c5492f3a8173',1,'ioperipherals.c']]]
];
