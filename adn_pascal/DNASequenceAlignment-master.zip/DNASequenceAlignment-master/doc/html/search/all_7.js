var searchData=
[
  ['g',['G',['../secuence_alignment_8c.html#aef4cec5b370242d799755d59d55bb8cc',1,'G():&#160;secuenceAlignment.c'],['../secuence_alignment_8h.html#aef4cec5b370242d799755d59d55bb8cc',1,'G():&#160;secuenceAlignment.h']]],
  ['generatedna',['generateDNA',['../secuence_alignment_8c.html#a0f9a7e820d79b4ce1ede99fba66756f6',1,'generateDNA(char *dna, int lenght):&#160;secuenceAlignment.c'],['../secuence_alignment_8h.html#a0f9a7e820d79b4ce1ede99fba66756f6',1,'generateDNA(char *dna, int lenght):&#160;secuenceAlignment.c']]],
  ['generatematrix',['generateMatrix',['../secuence_alignment_8c.html#abfbbbc609fc5ec0b12d76204a41454ee',1,'secuenceAlignment.c']]]
];
