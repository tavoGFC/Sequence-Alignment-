var searchData=
[
  ['bad_5fneocleotide',['BAD_NEOCLEOTIDE',['../secuence_alignment_8c.html#a8d68c482e74a03b5ac2e0175519e8a7f',1,'BAD_NEOCLEOTIDE():&#160;secuenceAlignment.c'],['../secuence_alignment_8h.html#a8d68c482e74a03b5ac2e0175519e8a7f',1,'BAD_NEOCLEOTIDE():&#160;secuenceAlignment.h']]]
];
