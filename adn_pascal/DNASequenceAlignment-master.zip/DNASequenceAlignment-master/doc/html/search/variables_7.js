var searchData=
[
  ['score_5fmatrix',['SCORE_MATRIX',['../secuence_alignment_8h.html#af05d5e81328c419aca4f1613123efd15',1,'secuenceAlignment.h']]],
  ['similarity_5fmatrix',['SIMILARITY_MATRIX',['../secuence_alignment_8c.html#a644fda768f24a8e4598f8c8749044bb2',1,'secuenceAlignment.c']]]
];
