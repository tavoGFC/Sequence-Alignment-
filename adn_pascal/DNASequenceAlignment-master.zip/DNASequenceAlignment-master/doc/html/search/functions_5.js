var searchData=
[
  ['initgaponscorematrix',['initGapOnScoreMatrix',['../secuence_alignment_8c.html#aa6af17a5d6337e40c1da85c09573dc01',1,'secuenceAlignment.c']]],
  ['invertstring',['invertString',['../secuence_alignment_8c.html#ab01ea520e6ded829ba0cf64a709b7389',1,'invertString(char *string):&#160;secuenceAlignment.c'],['../secuence_alignment_8h.html#ab01ea520e6ded829ba0cf64a709b7389',1,'invertString(char *string):&#160;secuenceAlignment.c']]],
  ['isdnafileextension',['isDNAFileExtension',['../secuence_alignment_8c.html#a669b425b1a868431a57fb4bbbf4e27d1',1,'isDNAFileExtension(char *filePath):&#160;secuenceAlignment.c'],['../secuence_alignment_8h.html#a669b425b1a868431a57fb4bbbf4e27d1',1,'isDNAFileExtension(char *filePath):&#160;secuenceAlignment.c']]],
  ['isnucleotide',['isNucleotide',['../secuence_alignment_8c.html#a7e3c5b96b23f8b57838076daeaa1707f',1,'secuenceAlignment.c']]],
  ['isvalidfilepath',['isValidFilePath',['../secuence_alignment_8c.html#af0ef913d4e5d6925efef029503ded166',1,'isValidFilePath(char *filepath):&#160;secuenceAlignment.c'],['../secuence_alignment_8h.html#af0ef913d4e5d6925efef029503ded166',1,'isValidFilePath(char *filepath):&#160;secuenceAlignment.c']]],
  ['isvalidnucleotidecontents',['isValidNucleotideContents',['../secuence_alignment_8c.html#abe6d8fb4993bd9936e0ed16b68746607',1,'isValidNucleotideContents(char *dna):&#160;secuenceAlignment.c'],['../secuence_alignment_8h.html#abe6d8fb4993bd9936e0ed16b68746607',1,'isValidNucleotideContents(char *dna):&#160;secuenceAlignment.c']]]
];
