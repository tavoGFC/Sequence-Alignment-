var searchData=
[
  ['t',['T',['../secuence_alignment_8c.html#a13f4c79df8afb02ae1f874bc509cd50b',1,'T():&#160;secuenceAlignment.c'],['../secuence_alignment_8h.html#a13f4c79df8afb02ae1f874bc509cd50b',1,'T():&#160;secuenceAlignment.h']]]
];
