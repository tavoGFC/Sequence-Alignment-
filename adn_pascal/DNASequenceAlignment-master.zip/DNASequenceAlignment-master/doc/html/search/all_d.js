var searchData=
[
  ['readfile',['readFile',['../iofile_8c.html#aec03413f45715232ccc4b277700b6a1e',1,'readFile(char *filePath):&#160;iofile.c'],['../iofile_8h.html#aec03413f45715232ccc4b277700b6a1e',1,'readFile(char *filePath):&#160;iofile.c']]],
  ['readme_2emd',['README.md',['../_r_e_a_d_m_e_8md.html',1,'']]]
];
