var searchData=
[
  ['data',['data',['../structdynamic_char.html#a0f11fc08c1ec2c8146ddd0d5b8fe8355',1,'dynamicChar']]]
];
