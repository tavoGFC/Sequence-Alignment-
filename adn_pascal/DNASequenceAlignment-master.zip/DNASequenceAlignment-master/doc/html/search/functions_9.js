var searchData=
[
  ['readfile',['readFile',['../iofile_8c.html#aec03413f45715232ccc4b277700b6a1e',1,'readFile(char *filePath):&#160;iofile.c'],['../iofile_8h.html#aec03413f45715232ccc4b277700b6a1e',1,'readFile(char *filePath):&#160;iofile.c']]]
];
