var searchData=
[
  ['scanint',['scanInt',['../ioperipherals_8c.html#a84dbd34a738ce2f61e3b233e6b13ded0',1,'scanInt(int *data):&#160;ioperipherals.c'],['../ioperipherals_8h.html#a84dbd34a738ce2f61e3b233e6b13ded0',1,'scanInt(int *data):&#160;ioperipherals.c']]],
  ['scanstring',['scanString',['../ioperipherals_8c.html#ab0c80ef6a68ce51b5fe952ee46bb6fe9',1,'scanString():&#160;ioperipherals.c'],['../ioperipherals_8h.html#ab0c80ef6a68ce51b5fe952ee46bb6fe9',1,'scanString():&#160;ioperipherals.c']]]
];
