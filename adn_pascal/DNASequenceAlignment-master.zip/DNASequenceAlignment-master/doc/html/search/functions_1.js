var searchData=
[
  ['convertchartonucletide',['convertCharToNucletide',['../secuence_alignment_8c.html#ac00f63d5094ad4e829e82a72bc8792a1',1,'convertCharToNucletide(char pCaracter):&#160;secuenceAlignment.c'],['../secuence_alignment_8h.html#a3bde964d3736e9f46f9921ff534b467d',1,'convertCharToNucletide(char pCharacter):&#160;secuenceAlignment.c']]],
  ['convertnucletidetochar',['convertNucletideToChar',['../secuence_alignment_8c.html#afe0feceb19e91dbf251c8b0364041fa9',1,'convertNucletideToChar(int pNucleotide):&#160;secuenceAlignment.c'],['../secuence_alignment_8h.html#afe0feceb19e91dbf251c8b0364041fa9',1,'convertNucletideToChar(int pNucleotide):&#160;secuenceAlignment.c']]],
  ['createfile',['createFile',['../iofile_8c.html#a5253be3d03a6b2f688e41423bafc74eb',1,'createFile(char *filePath, short int overwrite):&#160;iofile.c'],['../iofile_8h.html#a5253be3d03a6b2f688e41423bafc74eb',1,'createFile(char *filePath, short int overwrite):&#160;iofile.c']]]
];
