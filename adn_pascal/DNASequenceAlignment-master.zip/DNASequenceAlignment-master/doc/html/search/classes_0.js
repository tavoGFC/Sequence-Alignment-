var searchData=
[
  ['dynamicchar',['dynamicChar',['../structdynamic_char.html',1,'']]]
];
