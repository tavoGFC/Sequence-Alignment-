var searchData=
[
  ['next',['next',['../structdynamic_char.html#a22454f85c7e0f91bd08e23b3cbf9e9fc',1,'dynamicChar']]]
];
