var structdynamic_char =
[
    [ "data", "structdynamic_char.html#a0f11fc08c1ec2c8146ddd0d5b8fe8355", null ],
    [ "next", "structdynamic_char.html#a22454f85c7e0f91bd08e23b3cbf9e9fc", null ]
];