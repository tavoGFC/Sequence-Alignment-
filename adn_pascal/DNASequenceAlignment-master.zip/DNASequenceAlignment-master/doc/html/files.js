var files =
[
    [ "iofile.c", "iofile_8c.html", "iofile_8c" ],
    [ "iofile.h", "iofile_8h.html", "iofile_8h" ],
    [ "ioperipherals.c", "ioperipherals_8c.html", "ioperipherals_8c" ],
    [ "ioperipherals.h", "ioperipherals_8h.html", "ioperipherals_8h" ],
    [ "main.c", "main_8c.html", "main_8c" ],
    [ "secuenceAlignment.c", "secuence_alignment_8c.html", "secuence_alignment_8c" ],
    [ "secuenceAlignment.h", "secuence_alignment_8h.html", "secuence_alignment_8h" ],
    [ "secuenceGenerator.c", "secuence_generator_8c.html", "secuence_generator_8c" ]
];