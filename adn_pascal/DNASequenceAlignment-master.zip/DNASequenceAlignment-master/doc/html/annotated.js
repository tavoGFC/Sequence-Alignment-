var annotated =
[
    [ "dynamicChar", "structdynamic_char.html", "structdynamic_char" ]
];