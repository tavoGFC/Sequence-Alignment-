var ioperipherals_8h =
[
    [ "printlnFloat", "ioperipherals_8h.html#a07096a59d5287cf9647e8878def2ef88", null ],
    [ "printlnInt", "ioperipherals_8h.html#ae18dd1497ff58ee436c9db63d0475a93", null ],
    [ "printlnLong", "ioperipherals_8h.html#a6010f2d51fdbab10ac1e8874ddddc882", null ],
    [ "printlnShort", "ioperipherals_8h.html#a2100fa60d751d6c7b4dc308344170d93", null ],
    [ "printlnString", "ioperipherals_8h.html#adcbba9987fd6d3425b176a8a19766936", null ],
    [ "printlnUInt", "ioperipherals_8h.html#ac2ce9ee30c7b7caed5da2e8d913cbeb2", null ],
    [ "scanInt", "ioperipherals_8h.html#a84dbd34a738ce2f61e3b233e6b13ded0", null ],
    [ "scanString", "ioperipherals_8h.html#ab0c80ef6a68ce51b5fe952ee46bb6fe9", null ]
];